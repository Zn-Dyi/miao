


export default function NewFile() {


  return (
    <div>
      <svg className="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
        p-id="4932" width="20" height="20">
        <path
          d="M938.8032 983.04H81.92V40.96h568.32l287.4368 323.9936H590.848V122.88H163.84v778.24h693.0432V482.6112h81.92z m-266.24-699.5968h82.8416L672.768 189.44z"
          fill="#3080E9" p-id="4933"></path>
        <path d="M468.992 424.96h81.92v375.5008h-81.92z" fill="#3080E9" p-id="4934"></path>
        <path d="M322.1504 571.6992h375.5008v81.92H322.1504z" fill="#3080E9" p-id="4935"></path>
      </svg>
    </div>
  )
}
